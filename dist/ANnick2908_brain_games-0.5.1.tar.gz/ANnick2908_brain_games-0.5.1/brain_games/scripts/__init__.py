"""Package of scripts for package brain_game."""
